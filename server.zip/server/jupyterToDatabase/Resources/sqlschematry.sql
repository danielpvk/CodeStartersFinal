CREATE DATABASE cartera_vigente;
use cartera_vigente;
select * from cartera_vigente;
select Fecha, Cartera from cartera_vigente where Estado="Aguascalientes" AND Sector="Bancario";
